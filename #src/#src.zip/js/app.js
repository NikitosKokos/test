@@include('files/regular.js', {})
@@include('files/script.js', {})
@@include('files/forms.js', {})
@@include("files/some.js", {});
@@include('files/burger.js', {});
// @ @include("files/spoller.js",{});
// @ @include("files/select.js",{});
// @ @include("files/tabs.js",{});
    